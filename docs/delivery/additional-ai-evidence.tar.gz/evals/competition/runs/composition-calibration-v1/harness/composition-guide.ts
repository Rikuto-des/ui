import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {describe} from '../../packages/cli/src/catalog.ts';
import {examples, type Library} from './guides.ts';

/** Task-scoped references, frozen before responses. No test solutions. */
export async function guide(library: Library) {
  if (library !== 'urushi' && library !== 'base') throw Error('This study compares Urushi and Base UI only.');
  const usage = ['dialog','tabs','menu'].map(name => examples[library][name as 'dialog'|'tabs'|'menu']).join('\n\n');
  if (library === 'urushi') return usage + `\n\nimport {Combobox} from '@urushi/react/combobox';
type ComboboxOption={value:string;label:string;description?:string;disabled?:boolean};
<Combobox label="Owner" options={owners} value={ownerId} onValueChange={setOwnerId}/>
For server search use query/onQueryChange (search string, separate from committed value), filter="manual", and loading. Opening and selecting reset query to empty. Cache/preserve selected labels across result replacement is built in. Caller handles requests, stale response guards and errors; loading defaults to the built-in text "Loading…", so render any task-specific status separately. Input accepts normal native props/ref including disabled, required and name. It is disabled until hydrated. The runtime is already installed. Do not import CSS; harness installs selected styles and pack. Dialog is a native dialog with ref: HTMLDialogElement, showModal()/close(), native onCancel/onClose; onCancel preventDefault() cancels Escape. Root open/onOpenChange are unsupported. autoFocus is a native input/button prop. Use React state/effects when synchronizing a dynamic draft before opening. All HTML ids and target references must be unique.
Requested public contracts (native element props are also accepted unless excluded above):\n` + JSON.stringify(['dialog','tabs','menu','combobox'].map(name => { const d=describe(name);return {name,parts:d.parts.map(p=>({jsx:p.jsx,element:p.element,props:p.props})),keyboard:d.a11y.keyboard}; }));
  const dir=join(import.meta.dirname,'node_modules/@base-ui/react');
  const names=['dialog/root/DialogRoot.d.ts','dialog/popup/DialogPopup.d.ts','tabs/root/TabsRoot.d.ts','tabs/list/TabsList.d.ts','tabs/panel/TabsPanel.d.ts','menu/root/MenuRoot.d.ts','menu/item/MenuItem.d.ts','combobox/root/ComboboxRoot.d.ts','combobox/root/AriaCombobox.d.ts','combobox/input/ComboboxInput.d.ts','combobox/list/ComboboxList.d.ts','combobox/item/ComboboxItem.d.ts'];
  const types=await Promise.all(names.map(async name=>'\n'+name+'\n'+await readFile(join(dir,name),'utf8')));
  return usage + `\n\nimport {Combobox} from '@base-ui/react/combobox';
type Owner={value:string;label:string;disabled?:boolean};
<Combobox.Root items={owners} value={owner} onValueChange={setOwner} isItemEqualToValue={(a,b)=>a.value===b.value}>
  <label htmlFor="owner">Owner</label><Combobox.Input id="owner"/>
  <Combobox.Portal><Combobox.Positioner style={{zIndex:70}}><Combobox.Popup className="popup"><Combobox.List>{(item:Owner)=><Combobox.Item key={item.value} value={item} disabled={item.disabled}>{item.label}</Combobox.Item>}</Combobox.List><Combobox.Empty>No owners found</Combobox.Empty></Combobox.Popup></Combobox.Positioner></Combobox.Portal>
</Combobox.Root>
The selected value can be an object; keep that object available when remote items change. Objects with value/label use those fields automatically. Root inputValue/onInputValueChange control search text. filter={null} disables local filtering for server-ranked results. Caller handles requests, stale response guards, loading and errors. Parts accept native element props and refs. Popup className=modal, Backdrop className=backdrop, Menu.Popup className=menu and Combobox.Popup className=popup receive neutral styling from the harness; place portalled positioners above their parent dialog. No CSS imports needed.
Version-specific installed public type declarations:\n` + types.join('\n');
}
