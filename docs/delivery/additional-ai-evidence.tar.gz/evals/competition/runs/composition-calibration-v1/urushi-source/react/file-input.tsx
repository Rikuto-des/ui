import type * as React from "react";
import { fileInputDefaults, fileInputSlot, type FileInputOwnProps } from "./generated/file-input.ts";

export type FileInputProps = FileInputOwnProps & Omit<React.ComponentPropsWithRef<"input">, keyof FileInputOwnProps | "type">;

/**
 * A native file input. The dropzone variant is a large target: dropping files
 * on a file input is built into browsers, so it needs no JavaScript.
 */
export function FileInput({ variant = fileInputDefaults.variant, invalid = fileInputDefaults.invalid, ...rest }: FileInputProps) {
  return <input {...rest} type="file" data-slot={fileInputSlot} data-variant={variant} aria-invalid={invalid || rest["aria-invalid"] || undefined} />;
}
