import { defineContract, z, node } from "@urushi/contract";
export default defineContract({
 name: "combobox", tier: 3, summary: "検索して候補を絞り込み、1つの値を選択します。",
 use: ["検索して候補を絞り込み、1つの値を選択します。"], avoid: [{case: "検索や複雑な操作が不要な場合", instead: "select"}],
 rendering: "client", platform: {requires: ["React 19", "Popover API"]},
 parts: [{jsx: "Combobox", slot: "combobox", element: "div", description: "検索して候補を絞り込み、1つの値を選択します。", props: z.object({label: z.string().min(1).describe("画面に表示するラベル。必須です。"),
options: z.any().meta({"x-ts-type": 'readonly import("../combobox.tsx").ComboboxOption[]', description: "valueは一意にします。無効な候補はキーボード移動で飛ばします。"}),
value: z.string().optional(), defaultValue: z.string().optional(),
onValueChange: z.any().optional().meta({"x-ts-type": "(value: string) => void"}),
query: z.string().optional().describe("候補を検索する文字列。確定したvalueとは別に保持します。"),
onQueryChange: z.any().optional().meta({"x-ts-type": "(query: string) => void", description: "検索語の変更を受け取ります。候補を開くときと選択時には空文字になります。非同期取得の古い応答は呼び出し側で除外します。"}),
filter: z.enum(["local", "manual"]).default("local").describe("manualではoptionsを再絞り込みせず表示します。サーバー側で検索・順位付けするときに指定します。確定した選択の表示は候補が入れ替わっても保持します。"),
loading: z.boolean().optional(), emptyText: z.string().optional(),}), overrides: ["margin", "width", "layout", "position"]}],
 states: ["disabled", "empty", "focused"],
 a11y: {keyboard: {"ArrowDown / ArrowUp": "候補を開き、選択できる項目へ移動します", "Enter": "現在の候補を選択します", "Escape": "選択済みの値を変えずに閉じます", "Tab": "候補を閉じて次の入力欄へ移動します"}, rules: ["用途が伝わるlabelを指定します。", "候補・項目・行には重複しない固定のIDを指定します。", "組み合わせた画面を、対象の支援技術で確認してください。"]},
 tokens: ["color.text", "color.surface", "color.focus-ring", "radius.control"],
 examples: [{title: "Example", code: "<Combobox label=\"担当者\" options={[{ value: \"mika\", label: \"Mika Sato\" }, { value: \"kai\", label: \"Kai Ito\" }]} />"}]
});
