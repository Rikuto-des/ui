import { defineContract, z } from "@urushi/contract";

export default defineContract({
  name: "slider",
  tier: 1,
  summary: "A native <input type=\"range\"> in the pack's accent color.",
  use: ["An approximate value where the exact number matters less (音量, 明るさ)"],
  avoid: [{ case: "An exact number", instead: "input" }],
  rendering: "server",
  platform: { requires: ["accent-color"] },
  parts: [
    {
      jsx: "Slider",
      slot: "slider",
      element: "input",
      description: "The range input. Put it in a Field for its label; min, max, step and value are native.",
      props: z.object({}),
      overrides: ["margin", "width", "layout", "position"],
    },
  ],
  states: [],
  a11y: { keyboard: { "← / → / ↑ / ↓": "step", "Home / End": "min / max", "Page Up / Page Down": "larger steps" }, rules: ["Label it with a Field."] },
  tokens: ["color.accent"],
  examples: [{ title: "Volume", code: `<Field id="volume" label="音量"><Slider min={0} max={100} defaultValue={60} /></Field>` }],
});
