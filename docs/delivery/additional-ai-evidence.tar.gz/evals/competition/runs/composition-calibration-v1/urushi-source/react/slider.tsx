import type * as React from "react";
import { sliderSlot } from "./generated/slider.ts";

export type SliderProps = Omit<React.ComponentPropsWithRef<"input">, "type">;

/** A native range input in the pack's accent color. min, max, step and value are native. */
export function Slider(props: SliderProps) {
  return <input {...props} type="range" data-slot={sliderSlot} />;
}
