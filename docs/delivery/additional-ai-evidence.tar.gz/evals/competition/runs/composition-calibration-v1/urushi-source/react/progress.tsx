import { useId } from "react";
import type * as React from "react";
import { progressDefaults, progressSlot, type ProgressOwnProps } from "./generated/progress.ts";

export type ProgressProps = ProgressOwnProps & Omit<React.ComponentPropsWithRef<"progress">, keyof ProgressOwnProps | "children">;

/**
 * A visible label and a native <progress>. className and style go to the
 * wrapper; other props go to the <progress>. Without value it is indeterminate.
 */
export function Progress({ label, value, max = progressDefaults.max, showValue = progressDefaults.showValue, className, style, ...rest }: ProgressProps) {
  const id = useId();
  const percent = value === undefined ? undefined : Math.round((Math.min(Math.max(value, 0), max) / max) * 100);
  return (
    <div className={className} style={style} data-slot={progressSlot} data-indeterminate={value === undefined ? "" : undefined}>
      <div data-slot="progress-head">
        <span id={`${id}-label`} data-slot="progress-label">
          {label}
        </span>
        {showValue && percent !== undefined ? (
          // The bar itself announces its value; this copy is for the eye.
          <span data-slot="progress-value" aria-hidden="true">
            {percent}%
          </span>
        ) : null}
      </div>
      <progress {...rest} aria-labelledby={`${id}-label`} value={value} max={max} data-slot="progress-bar" />
    </div>
  );
}
