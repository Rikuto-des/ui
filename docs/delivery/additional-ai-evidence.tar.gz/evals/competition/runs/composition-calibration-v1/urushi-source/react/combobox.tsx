"use client";

import { useCallback, useEffect, useId, useLayoutEffect, useRef, useState, type ComponentPropsWithRef } from "react";

export interface ComboboxOption { value: string; label: string; description?: string; disabled?: boolean }
export interface ComboboxProps extends Omit<ComponentPropsWithRef<"input">, "value" | "defaultValue" | "onChange" | "type" | "size"> {
  label: string;
  options: readonly ComboboxOption[];
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  /** Search text while open, distinct from the committed option value. */
  query?: string;
  onQueryChange?: (query: string) => void;
  /** Use manual when a server already filters or ranks the supplied options. */
  filter?: "local" | "manual";
  loading?: boolean;
  emptyText?: string;
}

/** Single selection; editing searches, and Escape/blur restores the committed value. */
export function Combobox({ label, options, value: controlled, defaultValue = "", onValueChange, query: controlledQuery, onQueryChange, filter = "local", loading = false, emptyText = "No results found.", id: suppliedId, name, disabled, required, ref, ...inputProps }: ComboboxProps) {
  const uid = useId();
  const id = suppliedId ?? `combobox-${uid}`;
  const [local, setLocal] = useState(defaultValue);
  const value = controlled ?? local;
  const currentOption = options.find(option => option.value === value);
  // Remote result pages need not include the committed value. Remember only
  // selections, including earlier values a parent may restore on cancellation.
  const [selections, setSelections] = useState(() => new Map(currentOption ? [[value, currentOption]] : []));
  const remember = useCallback((option: ComboboxOption) => {
    setSelections(previous => {
      const saved = previous.get(option.value);
      if (saved?.label === option.label && saved?.description === option.description && saved?.disabled === option.disabled) return previous;
      return new Map(previous).set(option.value, option);
    });
  }, []);
  useEffect(() => { if (currentOption) remember(currentOption); }, [currentOption, remember]);
  const selected = currentOption ?? selections.get(value);
  const [open, setOpen] = useState(false);
  const [localQuery, setLocalQuery] = useState("");
  const query = controlledQuery ?? localQuery;
  const setQuery = useCallback((next: string) => { setLocalQuery(next); onQueryChange?.(next); }, [onQueryChange]);
  const [active, setActive] = useState(-1);
  // Server-rendered input must not accept edits before React can preserve them.
  const [ready, setReady] = useState(false);
  useEffect(() => { setReady(true); }, []);
  const input = useRef<HTMLInputElement>(null);
  const popup = useRef<HTMLDivElement>(null);
  const composing = useRef(false);
  const filtered = filter === "manual" ? options : options.filter(option => `${option.label} ${option.description ?? ""}`.toLocaleLowerCase().includes(query.toLocaleLowerCase()));
  const enabled = filtered.map((option, index) => option.disabled ? -1 : index).filter(index => index >= 0);
  const activeOption = open && !loading && active >= 0 && filtered[active] && !filtered[active].disabled ? `${id}-option-${active}` : undefined;
  function choose(option: ComboboxOption) {
    if (option.disabled) return;
    remember(option); setLocal(option.value); onValueChange?.(option.value); setOpen(false); setQuery("");
    input.current?.focus({ preventScroll: true });
  }
  function expand() { if (!disabled) { setQuery(""); setActive(-1); setOpen(true); } }
  useLayoutEffect(() => {
    const el = popup.current, anchor = input.current;
    if (!el || !anchor || !open || disabled) return;
    const place = () => {
      const rect = anchor.getBoundingClientRect();
      el.style.width = `${Math.min(rect.width, window.innerWidth - 16)}px`;
      el.style.left = `${Math.max(8, Math.min(rect.left, window.innerWidth - el.offsetWidth - 8))}px`;
      const below = window.innerHeight - rect.bottom - 12;
      const above = rect.top - 12;
      const down = below >= Math.min(280, el.scrollHeight) || below >= above;
      el.style.maxHeight = `${Math.max(64, down ? below : above)}px`;
      el.style.top = `${down ? rect.bottom + 6 : Math.max(8, rect.top - el.offsetHeight - 6)}px`;
    };
    el.showPopover(); place();
    const observer = new ResizeObserver(place); observer.observe(anchor);
    window.addEventListener("resize", place); window.addEventListener("scroll", place, true);
    const outside = (event: PointerEvent) => { if (!el.contains(event.target as Node) && event.target !== anchor) setOpen(false); };
    document.addEventListener("pointerdown", outside);
    return () => { observer.disconnect(); window.removeEventListener("resize", place); window.removeEventListener("scroll", place, true); document.removeEventListener("pointerdown", outside); if (el.matches(":popover-open")) el.hidePopover(); };
  }, [open, disabled, filtered.length, loading]);
  useEffect(() => { if (activeOption) document.getElementById(activeOption)?.scrollIntoView({ block: "nearest" }); }, [activeOption]);
  useEffect(() => { input.current?.setCustomValidity(required && !selected ? "Choose an option from the list." : ""); }, [required, selected]);
  useEffect(() => {
    const form = input.current?.form;
    const reset = () => { setLocal(defaultValue); setQuery(""); setOpen(false); };
    form?.addEventListener("reset", reset); return () => form?.removeEventListener("reset", reset);
  }, [defaultValue, setQuery]);
  return <div data-slot="combobox">
    <label htmlFor={id} data-slot="combobox-label">{label}</label>
    <div data-slot="combobox-control">
      <input {...inputProps} id={id} ref={node => { input.current = node; if (typeof ref === "function") return ref(node); if (ref) ref.current = node; }} data-slot="combobox-input" role="combobox" type="text" disabled={disabled || !ready} required={required} aria-required={required || undefined} autoComplete="off" aria-autocomplete="list" aria-expanded={open && !disabled} aria-controls={`${id}-list`} aria-activedescendant={activeOption} value={open ? query : selected?.label ?? ""}
        onClick={() => { if (!open) expand(); }} onChange={event => { setQuery(event.target.value); setActive(-1); setOpen(true); }}
        onCompositionStart={() => { composing.current = true; }} onCompositionEnd={() => { composing.current = false; }}
        onBlur={event => { inputProps.onBlur?.(event); setOpen(false); }}
        onKeyDown={event => {
          inputProps.onKeyDown?.(event); if (event.defaultPrevented || composing.current || event.nativeEvent.isComposing) return;
          if (event.key === "ArrowDown" || event.key === "ArrowUp") {
            event.preventDefault(); if (!open) { expand(); return; }
            const position = enabled.indexOf(active); const next = event.key === "ArrowDown" ? Math.min(position + 1, enabled.length - 1) : position < 0 ? enabled.length - 1 : Math.max(0, position - 1);
            setActive(enabled[next] ?? -1);
          } else if (event.key === "Enter" && open && activeOption) { event.preventDefault(); choose(filtered[active]); }
          else if (event.key === "Escape" && open) { event.preventDefault(); event.stopPropagation(); setOpen(false); }
          else if (event.key === "Tab") setOpen(false);
        }} />
      <span data-slot="combobox-chevron" aria-hidden="true">⌄</span>
    </div>
    {name && <input type="hidden" name={name} value={value} disabled={disabled} />}
    <div ref={popup} popover="manual" data-slot="combobox-popup" onKeyDown={event => { if (event.key === "Escape") { event.stopPropagation(); setOpen(false); input.current?.focus(); } }}>
      <div id={`${id}-list`} role="listbox" aria-label={label} aria-busy={loading || undefined}>
        {!loading && filtered.map((option, index) => <div key={option.value} id={`${id}-option-${index}`} role="option" aria-selected={option.value === value} aria-disabled={option.disabled || undefined} data-slot="combobox-option" data-active={active === index || undefined}
          onPointerDown={event => event.preventDefault()} onPointerMove={() => { if (!option.disabled) setActive(index); }} onClick={() => choose(option)}>
          <span>{option.label}{option.description && <small>{option.description}</small>}</span><span aria-hidden="true">{option.value === value ? "✓" : ""}</span>
        </div>)}
      </div>
      {(loading || filtered.length === 0) && <p data-slot="combobox-empty" role="status">{loading ? "Loading…" : emptyText}</p>}
    </div>
  </div>;
}
