import type * as React from "react";
import { kbdSlot } from "./generated/kbd.ts";

export type KbdProps = React.ComponentPropsWithRef<"kbd">;

export function Kbd(props: KbdProps) {
  return <kbd {...props} data-slot={kbdSlot} />;
}
