/**
 * Safari does not focus buttons on pointer activation. Focus the native
 * invoker before its default show-modal action so <dialog> can restore it.
 * Keyboard activation and focus trapping/closing remain native.
 */
export function installDialogInvokers(doc: Document = document): () => void {
  const click = (event: MouseEvent) => {
    if (event.defaultPrevented || !(event.target instanceof Element)) return;
    const invoker = event.target.closest<HTMLButtonElement>('button[data-slot~="button"][command="show-modal"]');
    if (!invoker || invoker.disabled || invoker.getAttribute('aria-disabled') === 'true') return;
    const dialog = doc.getElementById(invoker.getAttribute('commandfor') ?? '');
    if (!(dialog instanceof HTMLDialogElement) || dialog.open || !dialog.matches('[data-slot~="dialog"]')) return;
    invoker.focus({ preventScroll: true });
  };
  doc.addEventListener('click', click);
  return () => doc.removeEventListener('click', click);
}
